# My Founder Working Style

**The Trailblazer** (Big picture · Hands-off · Fast · Async)

You see where things are going and want to be there yesterday. You'd rather launch and adjust than wait for perfect.

## What I want from my Right Hand
- Owns outcomes end to end, not task lists
- Brings you decisions, never problems without options
- Decides alone on anything inside your limits and tells you after

**SOP detail:** Short SOPs: the outcome, the rules and when to escalate. Skip step-by-step detail the Right Hand can work out.
**Decide alone vs ask me:** The Right Hand decides alone on everything inside the dollar limit and the rules, and lists those decisions in the update.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Send 80% drafts early and improve them in the open. Speed beats polish on internal work.
