# My Founder Working Style

**The Optimizer** (Detail · Hands-off · Fast · Async)

You hate doing anything twice. You fix the process the moment it slows you down, and you'd rather automate today than plan for next month.

## What I want from my Right Hand
- Documents every process and keeps the SOPs current
- Runs the systems and reports by exception
- Suggests a rule or automation whenever something repeats

**SOP detail:** Rule-based SOPs: triggers, if/then rules, and what gets automated vs done by hand.
**Decide alone vs ask me:** The Right Hand follows the rules without asking and only escalates exceptions the rules don't cover.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Send 80% drafts early and improve them in the open. Speed beats polish on internal work.
