# My Founder Working Style

**The Captain** (Big picture · Hands-on · Async · Deliberate)

You lead from the front and like to steer. You want the big calls to stay yours, without doing the legwork.

## What I want from my Right Hand
- Prepares 2–3 options for every decision, with a recommendation
- Runs the follow-through the moment you decide
- Keeps a decisions log so nothing waits on your memory

**SOP detail:** SOPs centred on decision points: what the Right Hand prepares, what you choose, and what happens after.
**Decide alone vs ask me:** The Right Hand prepares and recommends; you make the final call on anything client-facing or new. Routine items follow the rules.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Double-check before anything goes out, and flag risks before they become problems. Polish beats speed on client-facing work.
