# My Founder Personality Type

**The Architect** (Detail · Hands-off · Deliberate · Live)

You like things to run on rules, not on you. You design the system carefully once so you never have to touch it again.

## What I want from my Right Hand
- Documents every process and keeps the SOPs current
- Runs the systems and reports by exception
- Suggests a rule or automation whenever something repeats

**SOP detail:** Rule-based SOPs: triggers, if/then rules, and what gets automated vs done by hand.
**Decide alone vs ask me:** The Right Hand follows the rules without asking and only escalates exceptions the rules don't cover.
**How to update me:** A 10-minute check-in call each day, followed by a short written recap of what was agreed.
**Drafts:** Double-check before anything goes out, and flag risks before they become problems. Polish beats speed on client-facing work.
