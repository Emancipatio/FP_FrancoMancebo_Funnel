# My Founder Personality Type

**The Visionary** (Big picture · Hands-off · Deliberate · Async)

You set the direction and want it handled well. You think in outcomes, lose energy in the details, and like big moves thought through.

## What I want from my Right Hand
- Owns outcomes end to end, not task lists
- Brings you decisions, never problems without options
- Decides alone on anything inside your limits and tells you after

**SOP detail:** Short SOPs: the outcome, the rules and when to escalate. Skip step-by-step detail the Right Hand can work out.
**Decide alone vs ask me:** The Right Hand decides alone on everything inside the dollar limit and the rules, and lists those decisions in the update.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Double-check before anything goes out, and flag risks before they become problems. Polish beats speed on client-facing work.
