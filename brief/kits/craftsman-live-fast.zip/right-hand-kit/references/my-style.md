# My Founder Personality Type

**The Maker** (Detail · Hands-on · Fast · Live)

You care how things are made, and you like making them quickly. You'd rather improve a real draft than plan the perfect one.

## What I want from my Right Hand
- Works from detailed SOPs with examples of your standard
- Shows you work at agreed checkpoints in the first 30 days
- Earns autonomy task by task as the checkpoints pass

**SOP detail:** Detailed SOPs: numbered steps, an example of a good result, and a quality checklist for every task.
**Decide alone vs ask me:** For the first 30 days you review at checkpoints; each task moves to 'decides alone' once it passes two reviews in a row.
**How to update me:** A 10-minute check-in call each day, followed by a short written recap of what was agreed.
**Drafts:** Send 80% drafts early and improve them in the open. Speed beats polish on internal work.
