# My Entrepreneur Personality Type

**The Commander** (Big picture · Hands-on · Fast · Async)

You lead from the front and decide fast. You want the big calls to stay yours and everything else moving now.

## What I want from my Right Hand
- Prepares 2–3 options for every decision, with a recommendation
- Runs the follow-through the moment you decide
- Keeps a decisions log so nothing waits on your memory

**SOP detail:** SOPs centred on decision points: what the Right Hand prepares, what you choose, and what happens after.
**Decide alone vs ask me:** The Right Hand prepares and recommends; you make the final call on anything client-facing or new. Routine items follow the rules.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Send 80% drafts early and improve them in the open. Speed beats polish on internal work.
