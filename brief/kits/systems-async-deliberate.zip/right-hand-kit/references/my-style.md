# My Founder Working Style

**The Systems Builder** (Detail · Hands-off · Async · Deliberate)

You like things to run on rules, not on you. You'd rather design the system once than touch it every day.

## What I want from my Right Hand
- Documents every process and keeps the SOPs current
- Runs the systems and reports by exception
- Suggests a rule or automation whenever something repeats

**SOP detail:** Rule-based SOPs: triggers, if/then rules, and what gets automated vs done by hand.
**Decide alone vs ask me:** The Right Hand follows the rules without asking and only escalates exceptions the rules don't cover.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Double-check before anything goes out, and flag risks before they become problems. Polish beats speed on client-facing work.
