# My Founder Working Style

**The Craftsman** (Detail · Hands-on · Async · Fast)

You care how things are done, not just that they're done. Quality is your signature, and it's why letting go is hard.

## What I want from my Right Hand
- Works from detailed SOPs with examples of your standard
- Shows you work at agreed checkpoints in the first 30 days
- Earns autonomy task by task as the checkpoints pass

**SOP detail:** Detailed SOPs: numbered steps, an example of a good result, and a quality checklist for every task.
**Decide alone vs ask me:** For the first 30 days you review at checkpoints; each task moves to 'decides alone' once it passes two reviews in a row.
**How to update me:** A written update at the end of each day (done / in progress / blocked / needs your decision). Urgent items only by direct message.
**Drafts:** Send 80% drafts early and improve them in the open. Speed beats polish on internal work.
